# Notification Service

Sending customer email/sms notification

Message structure

```json
{
    "channel": "email", // email, sms
    "address": "john@futureskill.com",
    "message": "Hello World"
}
```
